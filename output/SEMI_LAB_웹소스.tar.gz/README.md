# SEMI LAB

반도체 설비 인터랙티브 교육 플랫폼 첫 버전. 외부 CDN·패키지 없이 동작하는 정적 웹 앱입니다.

## 실행

이 폴더에서 `python3 -m http.server 8765 --directory dist`를 실행하고 http://localhost:8765 를 엽니다. 파일을 직접 여는 대신 HTTP로 제공해야 ES 모듈이 로드됩니다.

## 구현 범위

- 설비 라이브러리: 진공 공정 장비만 상세 예제로 구현. 이송·세정 장비는 준비 중.
- 전체/로드/펑션/언로드 및 계통 필터, 부품 검색과 경로 복귀.
- 3D 투영 Canvas 모델: 회전, 확대, 면 선택, 내부/분해, 치수와 이상 원통 체적.
- 교육용 레시피 단계와 관련 부품 강조. 정밀 물리 시뮬레이션 및 실제 제어 없음.
- 6개 부품의 구조·전장·원리·이해도 질문·출처·목업 설명.
- 교육용 BOM과 3D 선택 동기화, UTF-8 BOM 포함 CSV 내보내기.
- 한국어, 영어, 중국어 간체와 선택 기억. `?lang=ko`, `?lang=en`, `?lang=zh` 링크 지원.
- 부품 열람 기록은 현재 브라우저에 저장. 학습 성취 평가가 아닌 열람 표시.
- 직접 작성한 업데이트 브리핑. 이메일·자동 주간 발행 없음.

## 모듈 확장 구조

`dist/content.js`가 설비 레지스트리, 부품 콘텐츠, 레시피, 출처, 변경 기록을 제공합니다. `app.js`는 공통 탐색·BOM·퀴즈·뷰어 동작을 담당하고 `i18n.js`는 번역을 담당합니다. 부품 ID는 chamber, lid, stage, pump, valve, control로 고정합니다. BOM·3D 면·레시피·교육 패널이 같은 ID를 참조합니다. 새로운 장비는 콘텐츠 모듈과 레지스트리를 추가하고 해당 형상 어댑터를 연결하는 방식으로 확장합니다. 현재 GLB 로더와 서버 어댑터는 구현하지 않았습니다.

## .blend 원본과 GLB 파생 자산

원본 .blend는 서버/관리 영역에서 보관하고 버전·해시를 관리하는 구조를 제안합니다. 현재 업로드·변환·작업 큐·스토리지는 없습니다. 브라우저 모델은 웹에서 생성한 예제이며, 기존 Blender 장면은 수정하지 않았습니다.

1. .blend에 안정적인 partId와 설비/영역/계통 메타데이터를 부여합니다.
2. Geometry Nodes 입력을 허용 목록과 범위로 검증한 후, 격리된 Blender 작업에서 평가합니다.
3. 평가 형상을 GLB로 내보냅니다. GLB는 Blender 노드 그래프를 실행하지 않습니다. 이미지 렌더링은 별도 출력입니다.
4. custom properties를 glTF extras로 내보내고 부품 ID 매핑을 검사합니다. 원본 객체와 출력 mesh가 항상 1:1이라는 가정은 피합니다.
5. 재질 호환성, 텍스처, 형상, 축과 단위, 부품 매핑을 검토한 후 버전별 GLB와 매핑 파일을 게시합니다.
6. 웹에서 완료 작업의 결과를 가져와 모델을 교체합니다.

공식 Blender 매뉴얼에서 glTF custom properties/extras, evaluated mesh, 재질 체계 차이를 확인했습니다: https://docs.blender.org/manual/en/3.3/addons/import_export/scene_gltf2.html
명세: `dist/integration-contract.json`. 원본 외부 의존 파일, 지원 Blender/exporter 버전, 용량·시간 제한, 오류 처리, 접근 권한과 재생성 범위는 실제 모델 확보 후 결정합니다.

## 실물 목업

프린터 약 7억 원은 사용자 제시 도입 검토 금액이며 견적·총사업비·승인 예산이 아닙니다. 방식·재료·크기·후처리·유지비 미정. 웹 형상을 곧바로 제조 파일로 보지 않으며 벽 두께·공차·폐곡면·방향·서포트 등을 검토해야 합니다. 실제 설비 BOM과 목업 BOM은 별도로 관리해야 합니다.

## 지식 출처

- Pfeiffer Vacuum: https://www.pfeiffervacuum.com/no/en/knowledge/vacuum-technology/knowledge-book/4-vacuum-generation/
- Festo: https://www.festo.com/gb/en/c/products/actuators/pneumatic-cylinders-id_pim135
- SUNY Geneseo: https://milnepublishing.geneseo.edu/introtovacuumtech/chapter/an-introduction-to-vacuum-systems/

실제 장비별 콘텐츠와 절차는 학생·강사·설비 전문가 검수가 필요합니다.

추가 부품별 원리 자료:
- 커버의 압력·힘 관계, NASA Glenn: https://www1.grc.nasa.gov/beginners-guide-to-aeronautics/aerodynamic-force/
- 진공 환경의 열전달, NASA: https://www.nasa.gov/smallsat-institute/sst-soa/thermal-control/
- 센서·구동부 I/O 연결, Siemens: https://sieportal.siemens.com/en-ph/products-services/10231390
